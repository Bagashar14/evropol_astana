---
name: Europol Premium Design System
colors:
  surface: '#faf8fe'
  surface-dim: '#dad9df'
  surface-bright: '#faf8fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f8'
  surface-container: '#eeedf3'
  surface-container-high: '#e9e7ed'
  surface-container-highest: '#e3e2e7'
  on-surface: '#1a1b1f'
  on-surface-variant: '#46464a'
  inverse-surface: '#2f3034'
  inverse-on-surface: '#f1f0f5'
  outline: '#77767b'
  outline-variant: '#c7c6ca'
  surface-tint: '#5f5e60'
  primary: '#030304'
  on-primary: '#ffffff'
  primary-container: '#1d1d1f'
  on-primary-container: '#868587'
  inverse-primary: '#c8c6c8'
  secondary: '#7c5730'
  on-secondary: '#ffffff'
  secondary-container: '#fdcb9b'
  on-secondary-container: '#79542d'
  tertiary: '#020203'
  on-tertiary: '#ffffff'
  tertiary-container: '#1b1d1f'
  on-tertiary-container: '#848587'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e4e2e4'
  primary-fixed-dim: '#c8c6c8'
  on-primary-fixed: '#1b1b1d'
  on-primary-fixed-variant: '#474649'
  secondary-fixed: '#ffdcbd'
  secondary-fixed-dim: '#eebd8e'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#61401b'
  tertiary-fixed: '#e2e2e4'
  tertiary-fixed-dim: '#c6c6c8'
  on-tertiary-fixed: '#1a1c1d'
  on-tertiary-fixed-variant: '#454749'
  background: '#faf8fe'
  on-background: '#1a1b1f'
  surface-variant: '#e3e2e7'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
  button:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 80px
  margin-mobile: 20px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  section-gap: 120px
---

## Brand & Style

The design system is engineered to reflect the precision and premium quality of European laminate flooring. It targets a sophisticated audience in Kazakhstan—homeowners and interior designers seeking reliability and aesthetic excellence. 

The style is **Modern European Minimalism**, blending the technical precision of a tech brand with the functional warmth of high-end interior design. It prioritizes clarity, generous whitespace, and a rhythmic balance between high-tech interface elements and high-touch organic textures. The emotional response should be one of quiet confidence, institutional trust, and effortless premium service.

## Colors

The palette is anchored in high-contrast neutrals to ensure product imagery remains the focal point.

*   **Primary (Charcoal):** Used for primary text, iconography, and high-impact UI elements. It provides a grounded, authoritative feel.
*   **Secondary (Natural Oak):** Reserved for accent moments, interactive states, and price highlights. It mimics the warmth of premium wood.
*   **Surface (Apple Gray):** A soft, cool-toned gray used for backgrounds and container fills to reduce starkness and create depth.
*   **Background (Pure White):** The primary canvas, maximizing the perception of space and cleanliness.

## Typography

This design system utilizes **Inter** for its neutral, systematic clarity and excellent legibility at all scales. 

Headings use a tighter tracking for a bold, editorial look, while smaller labels use increased letter spacing and uppercase styling to evoke a technical, "spec-sheet" aesthetic. The hierarchy is steep, emphasizing clear section breaks and product titles. For larger headlines, optical kerning and slight negative letter spacing are required to maintain a premium "Apple-like" density.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy for desktop to maintain an editorial, catalog-like feel, while transitioning to a **Fluid Grid** for mobile. 

*   **Grid:** A 12-column grid is used for desktop (1440px max-width) with 24px gutters.
*   **Rhythm:** Vertical rhythm is strictly based on 8px increments. 
*   **Whitespace:** Large section gaps (120px+) are encouraged between different product categories or brand stories to allow the design to "breathe," mirroring the experience of a high-end showroom.
*   **Mobile:** Breakpoints at 768px (Tablet) and 375px (Mobile). Margins shrink to 20px on mobile to maximize screen real estate for product photography.

## Elevation & Depth

The design system employs **Tonal Layering** supplemented by **Ambient Shadows** to create a sense of tactile quality without visual clutter.

*   **Low Elevation:** Surface-on-surface (F5F5F7 on FFFFFF) with no shadow for secondary cards or inactive states.
*   **High Elevation:** Interactive product cards use a very soft, diffused shadow: `box-shadow: 0 10px 40px rgba(0,0,0,0.04)`. 
*   **Glassmorphism:** Navigation bars and sticky filters use a backdrop blur effect (20px blur) with 80% opacity to maintain context while scrolling through dense product lists.

## Shapes

The shape language is defined as **Rounded**, utilizing a 12px standard (0.75rem) for most UI components. This softens the technical aesthetic, making the interface feel approachable and interior-design focused. 

*   **Standard (rounded-md):** 12px for small cards and buttons.
*   **Large (rounded-lg):** 24px for featured hero cards and large image containers.
*   **Full (rounded-full):** Used exclusively for search bars and decorative tags/pills.

## Components

### Buttons
Primary CTAs use the **Primary (Charcoal)** color with white text, featuring 12px rounded corners. The hover state involves a slight scale-up (1.02x) rather than a color change. Secondary buttons use an outline style with a 1px charcoal border.

### Image Cards
Product cards are the core component. They feature high-resolution imagery, no visible border, a subtle 12px corner radius, and an ambient shadow on hover. Text within cards is left-aligned with a strict 16px padding from the image edge.

### Input Fields
Inputs are minimal, featuring a light gray background (`#F5F5F7`) and no border until focused. Upon focus, a 1px charcoal border appears. Labels are positioned above the field in the **label-caps** typography style.

### Filter Chips
Pill-shaped containers used for wood types (Oak, Walnut, Ash). Unselected states are light gray; selected states are **Secondary (Natural Oak)** with white text to highlight the organic nature of the product.

### Progress & Steppers
For the checkout or laminate calculator, use thin 2px lines in charcoal for active states and soft gray for inactive, emphasizing a minimalist, technical flow.